# ==============================================================================
# STEP 1 — ARCHIVAGE MENSUEL : PostgreSQL → S3
# Recipe Python Dataiku
# Input dataset  : ave_api_logs (PostgreSQL)
# Output dataset : audit_cold_s3 (S3 - dossier audit-cold/)
# Déclenchement  : 1er de chaque mois (via scénario Dataiku)
# ==============================================================================

import dataiku
import pandas as pd
import boto3
import io
import logging
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta

# ------------------------------------------------------------------------------
# LOGGING
# ------------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# ------------------------------------------------------------------------------
# PARAMÈTRES
# ------------------------------------------------------------------------------
SOURCE_DATASET_NAME = "ave_api_logs"
TIMESTAMP_COLUMN    = "timestamp"
S3_CONNECTION_NAME  = "S3-connexion"
S3_FOLDER           = "audit-cold"

# ------------------------------------------------------------------------------
# CALCUL DE LA PÉRIODE M-1 (mois calendaire complet)
# ------------------------------------------------------------------------------
now            = datetime.now(timezone.utc)
first_day_m1   = (now.replace(day=1) - relativedelta(months=1)).replace(
                    hour=0, minute=0, second=0, microsecond=0)
last_day_m1    = (now.replace(day=1) - relativedelta(microseconds=1)).replace(
                    hour=23, minute=59, second=59, microsecond=999999)
archive_label  = first_day_m1.strftime("%Y_%m")          # ex: 2025_01
csv_filename   = f"audit_{archive_label}.csv"

logger.info(f"Période à archiver : {first_day_m1} → {last_day_m1}")
logger.info(f"Fichier cible S3   : {S3_FOLDER}/{csv_filename}")

# ------------------------------------------------------------------------------
# LECTURE DEPUIS POSTGRESQL
# ------------------------------------------------------------------------------
logger.info("Lecture des données depuis PostgreSQL...")

source_dataset = dataiku.Dataset(SOURCE_DATASET_NAME)
df = source_dataset.get_dataframe()

# Assurer que la colonne timestamp est bien en datetime
df[TIMESTAMP_COLUMN] = pd.to_datetime(df[TIMESTAMP_COLUMN], utc=True)

# Filtrer sur le mois M-1
mask = (df[TIMESTAMP_COLUMN] >= first_day_m1) & (df[TIMESTAMP_COLUMN] <= last_day_m1)
df_to_archive = df[mask].copy()

count_source = len(df_to_archive)
logger.info(f"Lignes à archiver (PostgreSQL) : {count_source}")

if count_source == 0:
    logger.warning("Aucune donnée à archiver pour ce mois. Arrêt du script.")
    raise Exception(f"ARCHIVE_EMPTY: Aucune ligne trouvée pour la période {archive_label}. "
                    "Vérifier la table source avant de procéder à la suppression.")

# ------------------------------------------------------------------------------
# ÉCRITURE CSV EN MÉMOIRE
# ------------------------------------------------------------------------------
logger.info("Sérialisation en CSV...")
csv_buffer = io.StringIO()
df_to_archive.to_csv(csv_buffer, index=False, encoding="utf-8")
csv_content = csv_buffer.getvalue()

count_csv = df_to_archive.shape[0]
logger.info(f"Lignes sérialisées en CSV : {count_csv}")

# ------------------------------------------------------------------------------
# VÉRIFICATION COUNT (sécurité avant écriture S3)
# ------------------------------------------------------------------------------
if count_source != count_csv:
    raise Exception(
        f"COUNT_MISMATCH: Lignes PostgreSQL ({count_source}) ≠ lignes CSV ({count_csv}). "
        "Archivage annulé."
    )

# ------------------------------------------------------------------------------
# VÉRIFICATION IDEMPOTENCE : le fichier existe-t-il déjà sur S3 ?
# ------------------------------------------------------------------------------
logger.info("Vérification idempotence sur S3...")

s3_connection = dataiku.api_client().get_connection(S3_CONNECTION_NAME)
s3_params     = s3_connection.get_info()["params"]
bucket_name   = s3_params["bucket"]
s3_prefix     = s3_params.get("root", "").strip("/")
s3_key        = f"{s3_prefix}/{S3_FOLDER}/{csv_filename}".lstrip("/")

s3_client = boto3.client(
    "s3",
    aws_access_key_id     = s3_params.get("accessKey"),
    aws_secret_access_key = s3_params.get("secretKey"),
    region_name           = s3_params.get("region", "eu-west-1")
)

try:
    s3_client.head_object(Bucket=bucket_name, Key=s3_key)
    logger.warning(
        f"IDEMPOTENCE: Le fichier '{csv_filename}' existe déjà sur S3. "
        "Archivage ignoré pour éviter l'écrasement. "
        "Si vous souhaitez forcer le ré-archivage, supprimez manuellement le fichier S3."
    )
    raise Exception(
        f"ALREADY_ARCHIVED: {csv_filename} existe déjà dans S3. "
        "Step 2 (suppression) ne sera pas déclenché."
    )
except s3_client.exceptions.ClientError as e:
    if e.response["Error"]["Code"] == "404":
        logger.info("Fichier absent sur S3 — OK pour procéder à l'écriture.")
    else:
        raise Exception(f"S3_HEAD_ERROR: {str(e)}")

# ------------------------------------------------------------------------------
# ÉCRITURE SUR S3
# ------------------------------------------------------------------------------
logger.info(f"Écriture sur S3 : s3://{bucket_name}/{s3_key}")

s3_client.put_object(
    Bucket      = bucket_name,
    Key         = s3_key,
    Body        = csv_content.encode("utf-8"),
    ContentType = "text/csv"
)

logger.info("Écriture S3 terminée.")

# ------------------------------------------------------------------------------
# VÉRIFICATION POST-ÉCRITURE : le fichier existe et est non vide
# ------------------------------------------------------------------------------
logger.info("Vérification post-écriture sur S3...")

response = s3_client.head_object(Bucket=bucket_name, Key=s3_key)
s3_file_size = response["ContentLength"]

if s3_file_size == 0:
    raise Exception(
        f"S3_EMPTY_FILE: Le fichier '{csv_filename}' a été écrit mais est vide. "
        "Suppression PostgreSQL annulée."
    )

logger.info(f"Fichier S3 vérifié — taille : {s3_file_size} octets")

# ------------------------------------------------------------------------------
# RÉSUMÉ FINAL
# ------------------------------------------------------------------------------
logger.info("=" * 60)
logger.info("ARCHIVAGE TERMINÉ AVEC SUCCÈS")
logger.info(f"  Période archivée : {archive_label}")
logger.info(f"  Lignes archivées : {count_source}")
logger.info(f"  Fichier S3       : s3://{bucket_name}/{s3_key}")
logger.info(f"  Taille fichier   : {s3_file_size} octets")
logger.info("  → Step 2 (suppression PostgreSQL) peut être déclenché.")
logger.info("=" * 60)
