# ==============================================================================
# STEP 2 — SUPPRESSION DONNÉES HOT : PostgreSQL DELETE M-1
# Recipe Python Dataiku
# Input dataset  : ave_api_logs (PostgreSQL)
# Déclenchement  : UNIQUEMENT si Step 1 terminé avec succès
# ==============================================================================

import dataiku
import pandas as pd
import boto3
import logging
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta

# ------------------------------------------------------------------------------
# LOGGING
# ------------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# ------------------------------------------------------------------------------
# PARAMÈTRES
# ------------------------------------------------------------------------------
SOURCE_DATASET_NAME = "ave_api_logs"
TIMESTAMP_COLUMN    = "timestamp"
S3_CONNECTION_NAME  = "S3-connexion"
S3_FOLDER           = "audit-cold"

# ------------------------------------------------------------------------------
# CALCUL DE LA PÉRIODE M-1 (identique au Step 1)
# ------------------------------------------------------------------------------
now           = datetime.now(timezone.utc)
first_day_m1  = (now.replace(day=1) - relativedelta(months=1)).replace(
                    hour=0, minute=0, second=0, microsecond=0)
last_day_m1   = (now.replace(day=1) - relativedelta(microseconds=1)).replace(
                    hour=23, minute=59, second=59, microsecond=999999)
archive_label = first_day_m1.strftime("%Y_%m")
csv_filename  = f"audit_{archive_label}.csv"

logger.info(f"Période à supprimer : {first_day_m1} → {last_day_m1}")

# ------------------------------------------------------------------------------
# VÉRIFICATION PRÉALABLE : le fichier S3 existe-t-il bien ?
# (double sécurité avant toute suppression)
# ------------------------------------------------------------------------------
logger.info("Vérification existence fichier S3 avant suppression...")

s3_connection = dataiku.api_client().get_connection(S3_CONNECTION_NAME)
s3_params     = s3_connection.get_info()["params"]
bucket_name   = s3_params["bucket"]
s3_prefix     = s3_params.get("root", "").strip("/")
s3_key        = f"{s3_prefix}/{S3_FOLDER}/{csv_filename}".lstrip("/")

s3_client = boto3.client(
    "s3",
    aws_access_key_id     = s3_params.get("accessKey"),
    aws_secret_access_key = s3_params.get("secretKey"),
    region_name           = s3_params.get("region", "eu-west-1")
)

try:
    response     = s3_client.head_object(Bucket=bucket_name, Key=s3_key)
    s3_file_size = response["ContentLength"]

    if s3_file_size == 0:
        raise Exception(
            f"S3_EMPTY_FILE: Le fichier '{csv_filename}' existe sur S3 mais est vide. "
            "Suppression PostgreSQL annulée par sécurité."
        )

    logger.info(f"Fichier S3 confirmé : s3://{bucket_name}/{s3_key} ({s3_file_size} octets)")

except s3_client.exceptions.ClientError as e:
    if e.response["Error"]["Code"] == "404":
        raise Exception(
            f"S3_FILE_NOT_FOUND: Le fichier '{csv_filename}' est introuvable sur S3. "
            "Suppression PostgreSQL annulée — les données ne seraient pas archivées."
        )
    else:
        raise Exception(f"S3_HEAD_ERROR: {str(e)}")

# ------------------------------------------------------------------------------
# COMPTAGE LIGNES À SUPPRIMER (avant DELETE)
# ------------------------------------------------------------------------------
logger.info("Comptage des lignes à supprimer dans PostgreSQL...")

source_dataset = dataiku.Dataset(SOURCE_DATASET_NAME)
df             = source_dataset.get_dataframe()
df[TIMESTAMP_COLUMN] = pd.to_datetime(df[TIMESTAMP_COLUMN], utc=True)

mask            = (df[TIMESTAMP_COLUMN] >= first_day_m1) & (df[TIMESTAMP_COLUMN] <= last_day_m1)
count_to_delete = mask.sum()

logger.info(f"Lignes à supprimer : {count_to_delete}")

if count_to_delete == 0:
    logger.warning(
        "Aucune ligne à supprimer pour cette période. "
        "Peut-être déjà supprimées lors d'une exécution précédente."
    )
    # Pas une erreur bloquante — idempotent
else:
    # --------------------------------------------------------------------------
    # SUPPRESSION VIA SQL DIRECT (DELETE ciblé sur le mois M-1)
    # --------------------------------------------------------------------------
    logger.info("Exécution du DELETE sur PostgreSQL...")

    pg_connection  = source_dataset.get_config()["params"]["connection"]
    client         = dataiku.api_client()
    connection_obj = client.get_connection(pg_connection)

    # Utilisation du connecteur SQL Dataiku pour exécuter le DELETE
    import dataiku.core.sql as dku_sql

    query = f"""
        DELETE FROM ave_api_logs
        WHERE "{TIMESTAMP_COLUMN}" >= '{first_day_m1.strftime('%Y-%m-%d %H:%M:%S')}'
          AND "{TIMESTAMP_COLUMN}" <= '{last_day_m1.strftime('%Y-%m-%d %H:%M:%S')}'
    """

    logger.info(f"Requête DELETE : {query.strip()}")

    executor = dku_sql.SQLExecutor2(dataset=source_dataset)
    executor.query_to_df(query)

    logger.info(f"DELETE exécuté — {count_to_delete} lignes supprimées.")

    # --------------------------------------------------------------------------
    # VÉRIFICATION POST-SUPPRESSION
    # --------------------------------------------------------------------------
    logger.info("Vérification post-suppression...")

    df_after              = source_dataset.get_dataframe()
    df_after[TIMESTAMP_COLUMN] = pd.to_datetime(df_after[TIMESTAMP_COLUMN], utc=True)
    count_remaining_m1    = ((df_after[TIMESTAMP_COLUMN] >= first_day_m1) &
                             (df_after[TIMESTAMP_COLUMN] <= last_day_m1)).sum()

    if count_remaining_m1 > 0:
        raise Exception(
            f"DELETE_INCOMPLETE: {count_remaining_m1} lignes du mois {archive_label} "
            "sont encore présentes dans PostgreSQL après le DELETE."
        )

    logger.info("Vérification OK — aucune ligne résiduelle pour la période supprimée.")

# ------------------------------------------------------------------------------
# RÉSUMÉ FINAL
# ------------------------------------------------------------------------------
logger.info("=" * 60)
logger.info("SUPPRESSION TERMINÉE AVEC SUCCÈS")
logger.info(f"  Période supprimée  : {archive_label}")
logger.info(f"  Lignes supprimées  : {count_to_delete}")
logger.info(f"  Archive S3 validée : s3://{bucket_name}/{s3_key}")
logger.info("=" * 60)
