# Documentation — Historisation API Logs (Hot / Cold)
## Dataiku DSS 13.2 | PostgreSQL → S3

---

## Architecture du Flow

```
[ave_api_logs]          [step1_archivage.py]        [audit_cold_s3]
 PostgreSQL (hot)   →    Recipe Python (Step 1)   →   Dataset S3
                                ↓ succès
                    [step2_suppression.py]
                     Recipe Python (Step 2)
                      DELETE sur ave_api_logs
```

---

## Fichiers livrés

| Fichier | Rôle |
|---|---|
| `step1_archivage.py` | Recipe Python — lit PostgreSQL M-1, écrit CSV sur S3 |
| `step2_suppression.py` | Recipe Python — DELETE PostgreSQL M-1 après validation S3 |

---

## Mise en place dans Dataiku

### 1. Créer la Recipe Python Step 1 (Archivage)

1. Dans le Flow, cliquer sur `+Recipe` → `Python`
2. **Input** : dataset `ave_api_logs` (PostgreSQL)
3. **Output** : créer un nouveau dataset `audit_cold_s3`
   - Connection : `S3-connexion`
   - Format : CSV
   - Path : `audit-cold/`
4. Coller le contenu de `step1_archivage.py`
5. Sauvegarder

### 2. Créer la Recipe Python Step 2 (Suppression)

1. Dans le Flow, cliquer sur `+Recipe` → `Python`
2. **Input** : dataset `ave_api_logs` (PostgreSQL)
3. **Pas d'output dataset** (opération de suppression)
4. Coller le contenu de `step2_suppression.py`
5. Sauvegarder

### 3. Configurer le dataset S3 (audit_cold_s3)

1. Aller dans le dataset `audit_cold_s3`
2. Settings → connection : `S3-connexion`
3. Path : `audit-cold/`
4. Format : CSV, encoding UTF-8
5. Option **"List files in folder"** → activée (pour lire tous les CSV du dossier)
6. Ce dataset sera utilisé dans le dashboard pour la page cold data

### 4. Créer le Scénario Dataiku

1. Aller dans `Scenarios` → `+ New Scenario`
2. Nom : `Historisation_mensuelle_API_logs`
3. **Trigger** : Time-based
   - Fréquence : Monthly
   - Jour : 1er du mois
   - Heure : 00h00
4. **Steps** :

```
Step 1 : "Archivage S3"
  → Type : Run recipe
  → Recipe : step1_archivage (recipe Python archivage)
  → Stop on failure : OUI ✅

Step 2 : "Suppression PostgreSQL"
  → Type : Run recipe
  → Recipe : step2_suppression (recipe Python suppression)
  → Condition : uniquement si Step 1 = SUCCESS
  → Stop on failure : OUI ✅
```

5. **Reporters** (optionnel — notifications en cas d'échec) :
   - Aller dans `Reporters` du scénario
   - Ajouter un reporter de type `mail` ou `webhook`
   - Condition : `Run failed`

---

## Mécanismes de sécurité implémentés

| Mécanisme | Step | Description |
|---|---|---|
| Count check | Step 1 | Lignes PostgreSQL = lignes CSV avant écriture S3 |
| Idempotence | Step 1 | Si fichier S3 existe déjà → arrêt sans écraser |
| File existence check | Step 1 | Vérification que le fichier S3 est non vide après écriture |
| Pre-delete S3 check | Step 2 | Re-vérifie que le fichier S3 existe avant tout DELETE |
| Empty file guard | Step 2 | Refuse de supprimer si fichier S3 est vide |
| Post-delete check | Step 2 | Vérifie qu'aucune ligne résiduelle M-1 reste dans PostgreSQL |
| Stop on failure | Scénario | Step 2 ne se déclenche jamais si Step 1 a échoué |

---

## Nomenclature des fichiers S3

```
s3://[bucket]/audit-cold/audit_YYYY_MM.csv

Exemples :
  audit_2025_01.csv  → données de janvier 2025
  audit_2025_02.csv  → données de février 2025
  audit_2025_03.csv  → données de mars 2025
```

---

## Dashboard — Page Cold Data

Le dataset `audit_cold_s3` pointant sur le dossier `audit-cold/` lira 
automatiquement tous les fichiers CSV présents dans le dossier S3.

Pour afficher les données cold dans le dashboard Dataiku :
1. Utiliser le dataset `audit_cold_s3` comme source
2. Dataiku concatène automatiquement tous les fichiers CSV du dossier
3. Les données sont accessibles en lecture seule

---

## Points d'attention

- **Fuseau horaire** : les scripts utilisent UTC. Si votre PostgreSQL stocke 
  les timestamps en heure locale, ajuster `timezone.utc` en conséquence.
- **Permissions boto3** : les credentials S3 sont lus depuis la connexion 
  Dataiku `S3-connexion`. Vérifier que la connexion a les droits `s3:PutObject` 
  et `s3:HeadObject` sur le bucket.
- **Premier lancement** : le 1er février 2025 archivera janvier 2025. 
  Les données antérieures à janvier 2025 (actuellement dans PostgreSQL) 
  ne seront pas archivées automatiquement — un archivage manuel initial 
  peut être nécessaire si souhaité.
- **dateutil** : la librairie `python-dateutil` doit être disponible dans 
  l'environnement code Dataiku (généralement pré-installée).
